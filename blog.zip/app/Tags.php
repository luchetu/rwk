<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

class Tags extends Model
{
    //
}
