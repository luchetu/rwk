<?php

namespace App\Admin;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Events extends Model
{
    

}
